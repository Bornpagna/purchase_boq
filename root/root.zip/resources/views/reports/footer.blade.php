<div class="div-footer-report">
	<!-- <span class="footer-report">{{trans("lang.address")}} : {{getSetting()->company_address}} / {{trans("lang.email")}} : {{getSetting()->company_email}} / {{trans("lang.tel")}} : {{getSetting()->company_phone}}</span> -->
</div>