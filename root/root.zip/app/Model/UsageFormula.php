<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UsageFormula extends Model
{
    protected $table = "usage_formulas";
}
