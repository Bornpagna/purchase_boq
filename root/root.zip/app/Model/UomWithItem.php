<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UomWithItem extends Model
{
    protected $table = "uom_with_items";
}
