<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class UsageDetails extends Model
{
    protected $table = 'usage_details';
}
