<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Constructor extends Model
{
    protected $table = "constructors";
}
