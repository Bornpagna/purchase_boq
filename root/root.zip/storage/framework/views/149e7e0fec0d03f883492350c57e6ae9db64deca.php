<div class="approve-modal draggable-modal modal fade in" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title"></h4>
			</div>
			<div class="modal-body">
				<div class="portlet-body">
					<div class="mt-element-step">						
						<div class="row step-line">
							<div class="mt-step-desc">
								<div class="font-dark bold uppercase" id="step_line"></div>
								<br/> 
							</div>
							<div id="show-step">
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(trans('lang.cancel')); ?></button>
			</div>
		</div>
	</div>
</div>