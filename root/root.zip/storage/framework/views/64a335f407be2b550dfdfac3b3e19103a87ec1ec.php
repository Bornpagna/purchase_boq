<style>
	.boq-pointer{
		cursor: pointer;
	}
</style>
<form class="enter-boq-form form-horizontal" method="POST"  enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

	<div class="enter-boq-modal draggable-modal modal fade in" role="dialog">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title"></h4>
				</div>
				<div class="modal-body">
					<div class="form-body">
						<div class="form-group">
							<div class="col-md-12 text-center">
								<span class="show-message-error-boq center font-red bold"></span>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="boq-zone" class="col-md-12 bold"><?php echo e(trans('lang.zone')); ?> 
										<span class="required">*</span>
									</label>
									<div class="col-md-12">
										<select name="zone_id" id="boq-zone" class="form-control boq-zone my-select2">
											<option value=""></option>
											<?php echo e(getSystemData('ZN')); ?>

										</select>
										<span class="help-block font-red bold"></span>
									</div>
								</div>
							</div>

							<div class="col-md-4">
								<div class="form-group">
									<label for="boq-block" class="col-md-12 bold"><?php echo e(trans('lang.block')); ?> 
										<span class="required">*</span>
									</label>
									<div class="col-md-12">
										<select name="block_id" id="boq-block" class="form-control boq-block my-select2">
											<option value=""></option>
											<?php echo e(getSystemData('BK')); ?>

										</select>
										<span class="help-block font-red bold"></span>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="boq-building" class="col-md-12 bold"><?php echo e(trans('lang.building')); ?> 
										<span class="required">*</span>
									</label>
									<div class="col-md-12">
										<select name="building_id" id="boq-building" class="form-control boq-building my-select2">
											<option value=""></option>
											<?php echo e(getSystemData('BD')); ?>

										</select>
										<span class="help-block font-red bold"></span>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="boq-street" class="col-md-12 bold"><?php echo e(trans('lang.street')); ?> 
										
									</label>
									<div class="col-md-12">
										<select name="street_id" id="boq-street" class="form-control boq-street my-select2">
											<option value=""></option>
											<?php echo e(getSystemData('ST')); ?>

										</select>
										<span class="help-block font-red bold"></span>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="boq-house-type" class="col-md-12 bold"><?php echo e(trans('lang.house_type')); ?> 
										
									</label>
									<div class="col-md-12">
										<select name="house_type_id" id="boq-house-type" class="form-control boq-house-type my-select2">
											<option value=""></option>
											<?php echo e(getSystemData('HT')); ?>

										</select>
										<span class="help-block font-red bold"></span>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="boq-house" class="col-md-12 bold " id="label-house"><?php echo e(trans('lang.house_no')); ?> 
										
									</label>
									<div class="col-md-12 boq-house-wrapper">
										<select name="house[]" id="boq-house" class="form-control boq-house my-select2" multiple>
										
										</select>
										<span class="help-block font-red bold"></span>
									</div>
								</div>
							</div>
						</div>
						
						<div class="row">
							<div class="col-md-5">
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="boq-working-type" class="col-md-4 bold control-label" id="label-working-type"><?php echo e(trans('lang.working_type')); ?>

										<span class="required">*</span>
									</label>
									<div class="col-md-8">
										<select name="working_type" id="boq-working-type" class="form-control boq-working-type my-select2">
											<option value=""></option>
											<?php echo e(getSystemData('WK')); ?>

										</select>
										<span class="help-block font-red bold"></span>
									</div>
								</div>
							</div>
							<div class="col-md-1">
								<button type="button" class="btn btn-success boq-button-add-working-type" ><?php echo e(trans('lang.add')); ?></button>
							</div>
						</div>
						<table class="table table-hover no-footer" id="table_boq">
							<thead>
								<tr>
									<th class="text-center all" width="5%"><?php echo e(trans('lang.no')); ?></th>
									<th class="text-center all"><?php echo e(trans('lang.item_type')); ?></th>
									<th class="text-center all"><?php echo e(trans('lang.items')); ?></th>
									<th class="text-center all"><?php echo e(trans('lang.uom')); ?></th>
									<th class="text-center all"><?php echo e(trans('lang.qty_std')); ?></th>
									<th class="text-center all"><?php echo e(trans('lang.qty_add')); ?></th>
									<th class="text-center all"><?php echo e(trans('lang.cost')); ?></th>
									<th class="text-center all"><i class='fa fa-plus boq-pointer'></i></th>
								</tr>
							</thead>
							<tbody>
								
							</tbody>
						</table>
					</div>
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-success boq-button-submit" value="1"></button>
					<button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(trans('lang.cancel')); ?></button>
				</div>
			</div>
		</div>
	</div>
</form>
