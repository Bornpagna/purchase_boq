<div class="div-footer-report">
	<!-- <span class="footer-report"><?php echo e(trans("lang.address")); ?> : <?php echo e(getSetting()->company_address); ?> / <?php echo e(trans("lang.email")); ?> : <?php echo e(getSetting()->company_email); ?> / <?php echo e(trans("lang.tel")); ?> : <?php echo e(getSetting()->company_phone); ?></span> -->
</div>