<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo e(config('app.name')); ?> | <?php echo e(trans('lang.login')); ?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="<?php echo e(asset('assets/global/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/global/plugins/simple-line-icons/simple-line-icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/global/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo e(asset('assets/global/css/components-rounded.min.css')); ?>" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo e(asset('assets/global/css/plugins.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN PAGE LEVEL STYLES -->
        <link href="<?php echo e(asset('assets/pages/css/login.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" /> </head>
    <!-- END HEAD -->

    <body class=" login">
        <!-- BEGIN LOGO -->
        <div class="logo">
            <a><img src="<?php echo e(asset('assets/upload/temps/app_logo.png')); ?>" style="height: 100px;" alt="<?php echo e(config('app.name')); ?>" /> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
            <!-- BEGIN LOGIN FORM -->
            <form class="frmLogin" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
				<?php echo e(csrf_field()); ?>

				<div class="form-title">
                    <span class="form-title"><?php echo e(trans('lang.welcome')); ?></span>
                    <span class="form-subtitle"><?php echo e(trans('lang.please_login')); ?></span>
                </div>
                <div class="alert alert-danger display-hide">
                    <button class="close" data-close="alert"></button>
					<span></span>
                </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9"><?php echo e(trans('lang.email')); ?></label>
					<input id="email" type="email" placeholder="<?php echo e(trans('lang.email')); ?>" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

					<?php if($errors->has('email')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('email')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9"><?php echo e(trans('lang.password')); ?></label>
                    <input id="password" type="password" placeholder="<?php echo e(trans('lang.password')); ?>" class="form-control" name="password" required>

					<?php if($errors->has('password')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('password')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
                <div class="form-actions">
                    <button type="submit" id="btnLogin" name="btnLogin" class="btn red btn-block uppercase"><?php echo e(trans('lang.login')); ?></button>
                </div>
            </form>
            <!-- END LOGIN FORM -->
        </div>
        <div class="copyright">  <?= date('Y') ?> &copy; <?php echo e(trans('lang.purchase_system')); ?> </div>
        <!-- END LOGIN -->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo e(asset('assets/global/plugins/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/global/plugins/bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
    </body>
</html>
