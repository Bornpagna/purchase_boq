<div class="page-header navbar <?php if(getSetting()->page_header=="fixed"){echo "navbar-fixed-top";}else{echo "navbar-static-top";}?>">
    <!-- BEGIN HEADER INNER -->
    <div class="page-header-inner <?php if(getSetting()->theme_layout=="boxed"){ echo 'container';} ?>">
        <!-- BEGIN LOGO -->
        <div class="page-logo">
            <a>
                <img src="<?php echo e(asset('assets/upload/temps/app_logo.png')); ?>" alt="logo" class="logo-default" style="height: 35px;"/> 
			</a>
            <div class="menu-toggler sidebar-toggler" onclick="setSidebar()">
                <span></span>
            </div>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN RESPONSIVE MENU TOGGLER -->
        <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
            <span></span>
        </a>
        <!-- END RESPONSIVE MENU TOGGLER -->
        <!-- BEGIN TOP NAVIGATION MENU -->
        <div class="top-menu">
            <ul class="nav navbar-nav pull-right">
				<?php if(Session::get('project') != NULL): ?>
					<?php if(hasRole('approve') || hasRole('inventory')): ?>
					<li class="dropdown dropdown-extended dropdown-notification <?php if(getSetting()->top_menu_dropdown == "dark") echo "dropdown-dark"; ?>" id="header_notification_bar">
						<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
							<i class="icon-bell"></i>
							<span class="badge badge-default header_notification_counter"></span>
						</a>
						<ul class="dropdown-menu dropdown-menu-default">
							<li class="external">
								<h3><span class="bold header_notification_counter_span"></span> <?php echo e(trans('lang.notification')); ?></h3>
							</li>
							<li>
								<ul class="dropdown-menu-list scroller notification_lists" style="height: 250px;" data-handle-color="#637283"></ul>
							</li>
						</ul>
					</li>
					<?php endif; ?>
				<?php endif; ?>
				<!-- BEGIN USER LOGIN DROPDOWN -->
                <li class="dropdown dropdown-user <?php if(getSetting()->top_menu_dropdown == "dark") echo "dropdown-dark"; ?>">
                    <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                        <?php if(Auth::user()->photo=='' || Auth::user()->photo==null): ?>
							<img src="<?php echo e(asset('assets/layouts/layout/img/avatar3_small.jpg')); ?>" class="img-circle img-responsive" alt=""/>
						<?php else: ?>
							<img src="<?php echo e(asset('assets/upload/picture/users/'.Auth::user()->photo)); ?>" class="img-circle img-responsive" alt=""/> 
						<?php endif; ?>
						<span class="username username-hide-on-mobile"> <?php echo e(Auth::user()->name); ?> </span>
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-default">
                        <li>
                            <a href="<?php echo e(url('user/profile')); ?>"><i class="icon-user"></i><?php echo e(trans('lang.my_profile')); ?></a>
                        </li>
						<li>
                            <a href="<?php echo e(url('user/profile/pass')); ?>"><i class="icon-key"></i><?php echo e(trans('lang.change_password')); ?></a>
                        </li>
						<?php if(Session::get('project') != NULL): ?>
							<?php if(hasRole('approve')): ?>
								<li>
									<a href="<?php echo e(url('user/task')); ?>"><i class="icon-rocket"></i><?php echo e(trans('lang.my_tasks')); ?></a>
								</li>
							<?php endif; ?>
						<li>
                            <a href="<?php echo e(url('project')); ?>"><i class="fa fa-exchange"></i><?php echo e(trans('lang.swetch_project')); ?></a>
                        </li>
						<?php endif; ?>
                        <li class="divider"> </li>
                        <li>
                             <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="icon-lock"></i><?php echo e(trans('lang.logout')); ?></a>
							<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
								<?php echo e(csrf_field()); ?>

							</form>
                        </li>
                    </ul>
                </li>
				<!-- END USER LOGIN DROPDOWN -->
				
				<!-- BEGIN LANGUAGE BAR -->
				<li class="dropdown dropdown-language <?php if(getSetting()->top_menu_dropdown == "dark") echo "dropdown-dark"; ?>">
					<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
						
						<?php if(App::getLocale() == 'en'): ?>
							<i class="flag flag-gb"></i><span class="langname"> EN </span>
						<?php else: ?>
							<i class="flag flag-kh"></i><span class="langname"> KH </span>
						<?php endif; ?>
						<i class="fa fa-angle-down"></i>
					</a>
					<ul class="dropdown-menu dropdown-menu-default">
						<li>
                            <a onclick="getLanguage('kh')"><i class="flag flag-kh"></i> <?php echo e(trans('lang.khmer')); ?> </a>
                        </li>
                        <li>
							<a onclick="getLanguage('en')"><i class="flag flag-gb"></i> <?php echo e(trans('lang.english')); ?> </a>
                        </li> 
					</ul>
				</li>
				<!-- END LANGUAGE BAR -->
            </ul>
        </div>
        <!-- END TOP NAVIGATION MENU -->
    </div>
    <!-- END HEADER INNER -->
</div>
