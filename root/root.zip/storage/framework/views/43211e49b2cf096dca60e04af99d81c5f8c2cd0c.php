<!-- BEGIN SIDEBAR -->
<div class="page-sidebar navbar-collapse collapse">
	<!-- BEGIN SIDEBAR MENU -->
	<ul class="<?php if(getSetting()->page_header=="fixed"){echo "page-header-fixed";}?> <?php if(getSetting()->sidebar_style=="light"){echo "page-sidebar-menu-light";}?> <?php if(getSetting()->sidebar_menu=="hover"){echo "page-sidebar-menu-hover-submenu";}?> <?php if(getSetting()->sidebar_mode=="fixed"){echo "page-sidebar-menu-fixed";}else{echo "page-sidebar-menu-default";}?> page-sidebar-menu  <?php if(Session::get('sidebar')){ echo " page-sidebar-menu-closed "; } ?>" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
		
		
		<li class="nav-item start <?php if(Request::is('/')){echo "active open";} ?>">
			<a href="<?php echo e(url('/')); ?>" class="nav-link">
				<i class="fa fa-dashboard"></i>
				<span class="title"><?php echo e(trans('lang.dashboard')); ?></span>
				<span class="selected"></span>
			</a>
		</li>
	<?php if(hasRole('setup_option')): ?>
		<li class="nav-item <?php if(
			Request::is('usageFormula') ||
			Request::is('zone') || 
			Request::is('block') || 
			Request::is('street') || 
			Request::is('constr') || 
			Request::is('warehouse')){echo "active open";} ?>">
			<a  class="nav-link nav-toggle">
				<i class="icon-wrench"></i>
				<span class="title"><?php echo e(trans('lang.setup_option')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(
					Request::is('usageFormula') ||
					Request::is('zone') || 
					Request::is('block') || 
					Request::is('building') || 
					Request::is('street') || 
					Request::is('constr') || 
					Request::is('warehouse')){echo "open";}?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('zone')): ?>
				<?php if(getSetting()->allow_zone==1): ?>
				<li class="nav-item <?php if(Request::is('zone')){echo "active open";} ?>">
					<a href="<?php echo e(url('zone')); ?>" class="nav-link ">
						<i class="fa fa-th-large"></i>
						<span class="title"><?php echo e(trans('lang.zone')); ?></span>
						<?php if(Request::is('zone/')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(hasRole('block')): ?>
				<?php if(getSetting()->allow_block==1): ?>
				<li class="nav-item <?php if(Request::is('block')){echo "active open";} ?>">
					<a href="<?php echo e(url('block')); ?>" class="nav-link ">
						<i class="fa fa-square"></i>
						<span class="title"><?php echo e(trans('lang.block')); ?></span>
						<?php if(Request::is('block')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(hasRole('building')): ?>
				<?php if(getSetting()->allow_block==1): ?>
				<li class="nav-item <?php if(Request::is('building')){echo "active open";} ?>">
					<a href="<?php echo e(url('building')); ?>" class="nav-link ">
						<i class="fa fa-square"></i>
						<span class="title"><?php echo e(trans('lang.building')); ?></span>
						<?php if(Request::is('block')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(hasRole('street')): ?>
				<li class="nav-item <?php if(Request::is('street')){echo "active open";} ?>">
					<a href="<?php echo e(url('street')); ?>" class="nav-link ">
						<i class="fa fa-road"></i>
						<span class="title"><?php echo e(trans('lang.street')); ?></span>
						<?php if(Request::is('street')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('constructor')): ?>
				<li class="nav-item <?php if(Request::is('constr')){echo "active open";} ?>">
					<a href="<?php echo e(url('constr')); ?>" class="nav-link ">
						<i class="fa fa-user"></i>
						<span class="title"><?php echo e(trans('lang.constructor')); ?></span>
						<?php if(Request::is('constr')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('warehouse')): ?>
				<li class="nav-item <?php if(Request::is('warehouse')){echo "active open";} ?>">
					<a href="<?php echo e(url('warehouse')); ?>" class="nav-link ">
						<i class="fa fa-building"></i>
						<span class="title"><?php echo e(trans('lang.warehouse')); ?></span>
						<?php if(Request::is('warehouse')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(true): ?>
				<li class="nav-item <?php if(Request::is('usageFormula')){echo "active open";} ?>">
					<a href="<?php echo e(url('usageFormula')); ?>" class="nav-link ">
						<i class="fa fa-building"></i>
						<span class="title"><?php echo e(trans('lang.usage_formula')); ?></span>
						<?php if(Request::is('usageFormula')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>
	
	<?php if(hasRole('item_info')): ?>
		<li class="nav-item <?php if(Request::is('item_type') || Request::is('items') || Request::is('unit') || Request::is('supplier') || Request::is('supitems')){echo "active open";} ?>">
			<a  class="nav-link nav-toggle">
				<i class="fa fa-barcode"></i>
				<span class="title"><?php echo e(trans('lang.item_info')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('item_type') || Request::is('items') || Request::is('unit') || Request::is('supplier') || Request::is('supitems')){echo "open";}?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('item_type')): ?>
				<li class="nav-item <?php if(Request::is('item_type')){echo "active open";} ?>">
					<a href="<?php echo e(url('item_type')); ?>" class="nav-link ">
						<i class="fa fa-pie-chart"></i>
						<span class="title"><?php echo e(trans('lang.item_type')); ?></span>
						<?php if(Request::is('item_type')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>	
			<?php if(hasRole('unit')): ?>
				<li class="nav-item <?php if(Request::is('unit')){echo "active open";} ?>">
					<a href="<?php echo e(url('unit')); ?>" class="nav-link ">
						<i class="fa fa-refresh"></i>
						<span class="title"><?php echo e(trans('lang.unit_convert')); ?></span>
						<?php if(Request::is('unit')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('item')): ?>
				<li class="nav-item <?php if(Request::is('items')){echo "active open";} ?>">
					<a href="<?php echo e(url('items')); ?>" class="nav-link ">
						<i class="fa fa-tags"></i>
						<span class="title"><?php echo e(trans('lang.items')); ?></span>
						<?php if(Request::is('items')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('supplier')): ?>
				<li class="nav-item <?php if(Request::is('supplier')){echo "active open";} ?>">
					<a href="<?php echo e(url('supplier')); ?>" class="nav-link ">
						<i class="fa fa-user"></i>
						<span class="title"><?php echo e(trans('lang.supplier')); ?></span>
						<?php if(Request::is('supplier')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('supplier_item')): ?>
				<li class="nav-item <?php if(Request::is('supitems')){echo "active open";} ?>">
					<a href="<?php echo e(url('supitems')); ?>" class="nav-link ">
						<i class="fa fa-eyedropper"></i>
						<span class="title"><?php echo e(trans('lang.supplier_items')); ?></span>
						<?php if(Request::is('supitems')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>
	
	<?php if(hasRole('house_info')): ?>
		<li class="nav-item <?php if(Request::is('boqs') || Request::is('boqs/*') || Request::is('house') || Request::is('housetype')){echo "active open";} ?>">
			<a  class="nav-link nav-toggle">
				<i class="icon-home"></i>
				<span class="title"><?php echo e(trans('lang.house_info')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('boqs') || Request::is('house') || Request::is('housetype')){echo "open";}?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('house_type')): ?>
				<li class="nav-item <?php if(Request::is('housetype')){echo "active open";} ?>">
					<a href="<?php echo e(url('housetype')); ?>" class="nav-link ">
						<i class="fa fa-building-o"></i>
						<span class="title"><?php echo e(trans('lang.house_type')); ?></span>
						<?php if(Request::is('housetype')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('house')): ?>
				<li class="nav-item <?php if(Request::is('house')){echo "active open";} ?>">
					<a href="<?php echo e(url('house')); ?>" class="nav-link ">
						<i class="fa fa-home"></i>
						<span class="title"><?php echo e(trans('lang.house')); ?></span>
						<?php if(Request::is('house')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('boq')): ?>
				<li class="nav-item <?php if(Request::is('boqs') || Request::is('boqs/*')){echo "active open";} ?>">
					<a href="<?php echo e(url('boqs')); ?>" class="nav-link ">
						<i class="fa fa-bitcoin"></i>
						<span class="title"><?php echo e(trans('lang.boq')); ?></span>
						<?php if(Request::is('house')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>

	<?php if(hasRole('purchase')): ?>
		<li class="nav-item <?php if(Request::is('purch') || Request::is('purch/*')){echo "active open";} ?> ">
			<a  class="nav-link nav-toggle">
				<i class="icon-basket"></i>
				<span class="title"><?php echo e(trans('lang.purchase')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('purch')){echo "open";}?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('purchase_request')): ?>
				<li class="nav-item  <?php if(Request::is('purch/request') || Request::is('purch/request/*')){echo "active open";} ?>">
					<a href="<?php echo e(url('purch/request')); ?>" class="nav-link ">
						<i class="fa fa-registered"></i>
						<span class="title"><?php echo e(trans('lang.request')); ?></span>
						<?php if(Request::is('purch/request') || Request::is('purch/request/*')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('purchase_order')): ?>
				<li class="nav-item  <?php if(Request::is('purch/order') || Request::is('purch/order/*')){echo "active open";} ?>">
					<a href="<?php echo e(url('purch/order')); ?>" class="nav-link ">
						<i class="fa fa-shopping-cart"></i>
						<span class="title"><?php echo e(trans('lang.order')); ?></span>
						<?php if(Request::is('purch/order') || Request::is('purch/order/*')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>
	
	<?php if(hasRole('approve')): ?>
		<li class="nav-item <?php if(Request::is('approve') || Request::is('approve/*')){echo "active open";} ?> ">
			<a href="" class="nav-link nav-toggle">
				<i class="fa fa-check-square-o"></i>
				<span class="title"><?php echo e(trans('lang.approval')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('approve') || Request::is('approve/*')){echo "open";} ?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('approve_request')): ?>
				<li class="nav-item  <?php if(Request::is('approve/request')){echo "active open";} ?>">
					<a href="<?php echo e(url('approve/request')); ?>" class="nav-link ">
						<i class="fa fa-registered"></i>
						<span class="title"><?php echo e(trans('lang.request')); ?></span>
						<?php if(Request::is('approve/request')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('approve_order')): ?>
				<li class="nav-item  <?php if(Request::is('approve/order')){echo "active open";} ?>">
					<a href="<?php echo e(url('approve/order')); ?>" class="nav-link ">
						<i class="fa fa-shopping-cart"></i>
						<span class="title"><?php echo e(trans('lang.order')); ?></span>
						<?php if(Request::is('approve/order')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>
	
	<?php if(hasRole('inventory')): ?>
		<li class="nav-item <?php if(Request::is('stock') || Request::is('stock/*')){echo "active open";} ?>">
			<a href="" class="nav-link nav-toggle">
				<i class="fa fa-university"></i>
				<span class="title"><?php echo e(trans('lang.inventory')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('stock') || Request::is('stock/*')){echo "open";}?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('stock_entry')): ?>
				<li class="nav-item <?php if(Request::is('stock/entry') || Request::is('stock/entry/*')){echo "active open";} ?>">
					<a href="<?php echo e(url('stock/entry')); ?>" class="nav-link ">
						<i class="fa fa-sign-in"></i>
						<span class="title"><?php echo e(trans('lang.stock_entry')); ?></span>
						<?php if(Request::is('stock/entry') || Request::is('stock/entry/*')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('stock_import')): ?>
				<li class="nav-item <?php if(Request::is('stock/import')){echo "active open";} ?>">
					<a href="<?php echo e(url('stock/import')); ?>" class="nav-link ">
						<i class="fa fa-upload"></i>
						<span class="title"><?php echo e(trans('lang.stock_import')); ?></span>
						<?php if(Request::is('stock/import')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('stock_balance')): ?>
				<li class="nav-item <?php if(Request::is('stock/balance') || Request::is('stock/balance/*')){echo "active open";} ?>">
					<a href="<?php echo e(url('stock/balance')); ?>" class="nav-link ">
						<i class="fa fa-balance-scale"></i>
						<span class="title"><?php echo e(trans('lang.stock_balance')); ?></span>
						<?php if(Request::is('stock/balance') || Request::is('stock/balance/*')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('stock_adjust')): ?>
				<li class="nav-item <?php if(Request::is('stock/adjust') || Request::is('stock/adjust/*')){echo "active open";} ?>">
					<a href="<?php echo e(url('stock/adjust')); ?>" class="nav-link ">
						<i class="fa fa-adjust"></i>
						<span class="title"><?php echo e(trans('lang.adjustment')); ?></span>
						<?php if(Request::is('stock/adjust') || Request::is('stock/adjust/*')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('stock_move')): ?>
				<li class="nav-item <?php if(Request::is('stock/move') || Request::is('stock/move/*')){echo "active open";} ?>">
					<a href="<?php echo e(url('stock/move')); ?>" class="nav-link ">
						<i class="fa fa-arrows"></i>
						<span class="title"><?php echo e(trans('lang.movement')); ?></span>
						<?php if(Request::is('stock/move') || Request::is('stock/move/*')){echo '<span class="selected"></span>';} ?>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('delivery')): ?>
				<li class="nav-item start <?php if(Request::is('stock/deliv') || Request::is('stock/deliv/*') || Request::is('stock/redeliv') || Request::is('stock/redeliv/*')){echo "active open";} ?>">
					<a  class="nav-link nav-toggle">
						<i class="fa fa-truck"></i>
						<span class="title"><?php echo e(trans('lang.delivery')); ?></span>
						<span class="arrow <?php if(Request::is('stock/deliv') || Request::is('stock/deliv/*') || Request::is('stock/redeliv') || Request::is('stock/redeliv/*')){echo "open";} ?>"></span>
					</a>
					<ul class="sub-menu">
					<?php if(hasRole('delivery_entry')): ?>	
						<li class="nav-item <?php if(Request::is('stock/deliv') || Request::is('stock/deliv/*')){echo "active open";} ?>">
							<a href="<?php echo e(url('stock/deliv')); ?>" class="nav-link ">
								<i class="fa fa-sign-in"></i>
								<span class="title"><?php echo e(trans('lang.entry')); ?></span>
								<?php if(Request::is('stock/deliv') || Request::is('stock/deliv/*')){echo '<span class="selected"></span>';} ?>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('delivery_return')): ?>
						<li class="nav-item <?php if(Request::is('stock/redeliv') || Request::is('stock/redeliv/*')){echo "active open";} ?>">
							<a href="<?php echo e(url('stock/redeliv')); ?>" class="nav-link ">
								<i class="fa fa-exchange"></i>
								<span class="title"><?php echo e(trans('lang.return')); ?></span>
								<?php if(Request::is('stock/redeliv') || Request::is('stock/redeliv/*')){echo '<span class="selected"></span>';} ?>
							</a>
						</li>
					<?php endif; ?>
					</ul>
				</li>
			<?php endif; ?>
			<?php if(hasRole('usage')): ?>
				<li class="nav-item start <?php if(Request::is('stock/reuse_single') || Request::is('stock/reuse_single/*') || Request::is('stock/use_single') || Request::is('stock/use_single/*') || Request::is('stock/use') || Request::is('stock/use/*') || Request::is('stock/reuse') || Request::is('stock/reuse/*')){echo "active open";} ?>">
					<a  class="nav-link nav-toggle">
						<i class="fa fa-legal"></i>
						<span class="title"><?php echo e(trans('lang.usage')); ?></span>
						<span class="arrow <?php if(Request::is('stock/reuse_single') || Request::is('stock/reuse_single/*') || Request::is('stock/use_single') || Request::is('stock/use_single/*') || Request::is('stock/use') || Request::is('stock/use/*') || Request::is('stock/reuse') || Request::is('stock/reuse/*')){echo "open";} ?>"></span>
					</a>
					<ul class="sub-menu">
					<?php if(hasRole('usage_entry')): ?>
						<li class="nav-item <?php if(Request::is('stock/use') || Request::is('stock/use/*')){echo "active open";} ?>">
							<a href="<?php echo e(url('stock/use')); ?>" class="nav-link ">
								<i class="fa fa-sign-in"></i>
								<span class="title"><?php echo e(trans('lang.entry')); ?></span>
								<?php if(Request::is('stock/use') || Request::is('stock/use/*')){echo '<span class="selected"></span>';} ?>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('usage_entry')): ?>
						<li class="nav-item <?php if(Request::is('stock/use_single') || Request::is('stock/use_single/*')){echo "active open";} ?>">
							<a href="<?php echo e(url('stock/use_single')); ?>" class="nav-link ">
								<i class="fa fa-sign-in"></i>
								<span class="title"><?php echo e(trans('lang.entry_single')); ?></span>
								<?php if(Request::is('stock/use_single') || Request::is('stock/use_single/*')){echo '<span class="selected"></span>';} ?>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('usage_entry')): ?>
					<!-- Usage with Policy -->
					<li class="nav-item <?php if(Request::is('stock/use/policy') || Request::is('stock/use/policy/*')){echo "active open";} ?>">
						<a href="<?php echo e(url('stock/use/policy')); ?>" class="nav-link ">
							<i class="fa fa-sign-in"></i>
							<span class="title"><?php echo e(trans('lang.usage_with_policy')); ?></span>
							<?php if(Request::is('stock/use/policy') || Request::is('stock/use/policy/*')){echo '<span class="selected"></span>';} ?>
						</a>
					</li>
					<!-- End Usage with Policy -->
					<?php endif; ?>
					<?php if(hasRole('usage_return')): ?>
						<li class="nav-item <?php if(Request::is('stock/reuse') || Request::is('stock/reuse/*')){echo "active open";} ?>">
							<a href="<?php echo e(url('stock/reuse')); ?>" class="nav-link ">
								<i class="fa fa-exchange"></i>
								<span class="title"><?php echo e(trans('lang.return')); ?></span>
								<?php if(Request::is('stock/reuse') || Request::is('stock/reuse/*')){echo '<span class="selected"></span>';} ?>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('usage_return')): ?>
						<li class="nav-item <?php if(Request::is('stock/reuse_single') || Request::is('stock/reuse_single/*')){echo "active open";} ?>">
							<a href="<?php echo e(url('stock/reuse_single')); ?>" class="nav-link ">
								<i class="fa fa-exchange"></i>
								<span class="title"><?php echo e(trans('lang.return_single')); ?></span>
								<?php if(Request::is('stock/reuse_single') || Request::is('stock/reuse_single/*')){echo '<span class="selected"></span>';} ?>
							</a>
						</li>
					<?php endif; ?>
					</ul>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>	
	
	<?php if(hasRole('report')): ?>
		<li class="nav-item <?php if(Request::is('report/*')){echo "active open";} ?> ">
			<a  class="nav-link nav-toggle">
				<i class="icon-bar-chart"></i>
				<span class="title"><?php echo e(trans('lang.report')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('report')){echo "open";}?>"></span>
			</a>
			<ul class="sub-menu">
				<?php if(hasRole('report_boq')): ?>
					<li class="nav-item start <?php if(Request::is('report/sub_boq') 
							|| Request::is('report/boq_detail') 
							|| Request::is('report/boq/reportRemainingBOQ')
							|| Request::is('report/boq/reportRemainingBOQTotal')
						){echo "active open";} ?>">
						<a class="nav-link nav-toggle">
							<i class="fa fa-bitcoin"></i>
							<span class="title"><?php echo e(trans('lang.boq')); ?></span>
							<span class="arrow <?php if(Request::is('report/sub_boq') 
								|| Request::is('report/boq_detail') 
								|| Request::is('report/boq/reportRemainingBOQ')
								|| Request::is('report/boq/reportRemainingBOQTotal')
							){echo "open";} ?>"></span>
						</a>
						<ul class="sub-menu">
							<?php if(hasRole('report_boq_detail')): ?>
								<li class="nav-item <?php if(Request::is('report/boq_detail')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/boq_detail')); ?>" class="nav-link ">
										<i class="fa fa-building-o"></i>
										<span class="title"><?php echo e(trans('rep.boq_detail')); ?></span>
										<span class="<?php if(Request::is('report/boq_detail')){echo "selected";} ?>"></span>
									</a>
								</li> 
							<?php endif; ?>
							<?php if(false): ?>
								<li class="nav-item <?php if(Request::is('report/sub_boq')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/sub_boq')); ?>" class="nav-link ">
										<i class="fa fa-home"></i>
										<span class="title"><?php echo e(trans('rep.sub_boq')); ?></span>
										<span class="<?php if(Request::is('report/sub_boq')){echo "selected";} ?>"></span>
									</a>
								</li>
							<?php endif; ?>
							<!-- Report Remaining BOQ(Each House) -->
							<li class="nav-item <?php if(Request::is('report/boq/reportRemainingBOQ')){echo "active open";} ?>">
								<a href="<?php echo e(url('report/boq/reportRemainingBOQ')); ?>" class="nav-link ">
									<i class="fa fa-home"></i>
									<span class="title"><?php echo e(trans('lang.report_remaining_boq')); ?></span>
									<span class="<?php if(Request::is('report/boq/reportRemainingBOQ')){echo "selected";} ?>"></span>
								</a>
							</li>
							<!-- Report Remaining BOQ(Total) -->
							<li class="nav-item <?php if(Request::is('report/boq/reportRemainingBOQTotal')){echo "active open";} ?>">
								<a href="<?php echo e(url('report/boq/reportRemainingBOQTotal')); ?>" class="nav-link ">
									<i class="fa fa-home"></i>
									<span class="title"><?php echo e(trans('lang.report_remaining_boq_total')); ?></span>
									<span class="<?php if(Request::is('report/boq/reportRemainingBOQTotal')){echo "selected";} ?>"></span>
								</a>
							</li>
						</ul>
					</li>
				<?php endif; ?>
				<?php if(hasRole('report_usage')): ?>
					<li class="nav-item start <?php if(Request::is('report/usage') 
						|| Request::is('report/usage-house')
						|| Request::is('report/usage/compareBOQWithUsage')
						|| Request::is('report/usage-costing')
						|| Request::is('report/usage/return')
					){echo "active open";} ?>">
						<a  class="nav-link nav-toggle">
							<i class="fa fa-legal"></i>
							<span class="title"><?php echo e(trans('lang.usage')); ?></span>
							<span class="arrow <?php if(
								Request::is('report/usage') 
								|| Request::is('report/usage-house') 
								|| Request::is('report/usage/compareBOQWithUsage')
								|| Request::is('report/usage-costing')
								|| Request::is('report/usage/return')
							){echo "open";} ?>"></span>
						</a>
						<ul class="sub-menu">
							<?php if(hasRole('report_usage_entry')): ?>
								<li class="nav-item <?php if(Request::is('report/usage-house')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/usage-house')); ?>" class="nav-link ">
										<i class="fa fa-building-o"></i>
										<span class="title"><?php echo e(trans('rep.usage_house')); ?></span>
										<span class="<?php if(Request::is('report/usage-house')){echo "selected";} ?>"></span>
									</a>
								</li> 
							<?php endif; ?>
							<?php if(hasRole('report_usage_entry')): ?>
								<li class="nav-item <?php if(Request::is('report/usage')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/usage')); ?>" class="nav-link ">
										<i class="fa fa-building-o"></i>
										<span class="title"><?php echo e(trans('rep.usage')); ?></span>
										<span class="<?php if(Request::is('report/usage')){echo "selected";} ?>"></span>
									</a>
								</li> 
							<?php endif; ?>							
							<?php if(hasRole('report_usage_entry')): ?>
								<li class="nav-item <?php if(Request::is('report/usage/compareBOQWithUsage')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/usage/compareBOQWithUsage')); ?>" class="nav-link ">
										<i class="fa fa-building-o"></i>
										<span class="title"><?php echo e(trans('lang.report_usage_with_boq')); ?></span>
										<span class="<?php if(Request::is('report/usage/compareBOQWithUsage')){echo "selected";} ?>"></span>
									</a>
								</li> 
							<?php endif; ?>
							<?php if(hasRole('report_usage_entry') && getSetting()->is_costing==1): ?>
								<li class="nav-item <?php if(Request::is('report/usage-costing')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/usage-costing')); ?>" class="nav-link ">
										<i class="fa fa-dollar"></i>
										<span class="title"><?php echo e(trans('rep.report_usage_costing')); ?></span>
										<span class="<?php if(Request::is('report/usage-costing')){echo "selected";} ?>"></span>
									</a>
								</li> 
							<?php endif; ?>
							<?php if(hasRole('report_return_usage')): ?>
								<li class="nav-item <?php if(Request::is('report/usage/return')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/usage/return')); ?>" class="nav-link ">
										<i class="fa fa-home"></i>
										<span class="title"><?php echo e(trans('rep.return_usage')); ?></span>
										<span class="<?php if(Request::is('report/usage/return')){echo "selected";} ?>"></span>
									</a>
								</li>
							<?php endif; ?>
						</ul>
					</li>
				<?php endif; ?>
				<?php if(hasRole('report_purchase')): ?>
					<li class="nav-item start <?php if(Request::is('report/purchase_items') || Request::is('report/purchase/*') || Request::is('report/delivery') || Request::is('report/return') || Request::is('report/delivery_details')){echo "active open";} ?>">
						<a  class="nav-link nav-toggle">
							<i class="icon-basket"></i>
							<span class="title"><?php echo e(trans('lang.purchase')); ?></span>
							<span class="arrow <?php if(Request::is('report/purchase_items') || Request::is('report/purchase/*') || Request::is('report/delivery') || Request::is('report/return') || Request::is('report/delivery_details')){echo "open";} ?>"></span>
						</a>
						<ul class="sub-menu">
							<?php if(hasRole('report_purchase_request')): ?>
								<li class="nav-item <?php if(Request::is('report/purchase-detail') || Request::is('report/purchase/request/*') || Request::is('report/purchase-detail')){echo "active open";} ?>">
									<a  class="nav-link nav-toggle">
										<i class="fa fa-registered"></i>
										<span class="title"><?php echo e(trans('lang.request')); ?></span>
										<span class="arrow <?php if(Request::is('report/purchase/request') || Request::is('report/purchase/request/*') || Request::is('report/purchase-detail')){echo "open";} ?>"></span>
									</a>
									<ul class="sub-menu">
										<?php if(hasRole('report_purchase_request_1')): ?>
											<li class="nav-item <?php if(Request::is('report/purchase-detail')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/purchase-detail')); ?>" class="nav-link ">
													<i class="fa fa-file-pdf-o"></i>
													<span class="title"><?php echo e(trans('rep.report_purchase_request_detail')); ?></span>
													<span class="<?php if(Request::is('report/purchase-detail')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
										<?php if(hasRole('report_purchase_request_1')): ?>
											<li class="nav-item <?php if(Request::is('report/purchase/request/request_1')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/purchase/request/request_1')); ?>" class="nav-link ">
													<i class="fa fa-file-pdf-o"></i>
													<span class="title"><?php echo e(trans('rep.request_1')); ?></span>
													<span class="<?php if(Request::is('report/purchase/request/request_1')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
										<?php if(hasRole('report_purchase_request_2')): ?>
											<li class="nav-item <?php if(Request::is('report/purchase-request-and-order')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/purchase-request-and-order')); ?>" class="nav-link ">
													<i class="fa fa-file-pdf-o"></i>
													<span class="title"><?php echo e(trans('rep.report_purchase_and_order')); ?></span>
													<span class="<?php if(Request::is('report/purchase-request-and-order')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
										<?php if(hasRole('report_purchase_request_3')): ?>
											<li class="nav-item <?php if(Request::is('report/purchase-request-and-order-delivery')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/purchase-request-and-order-delivery')); ?>" class="nav-link ">
													<i class="fa fa-file-pdf-o"></i>
													<span class="title"><?php echo e(trans('rep.report_purchase_and_order_delivery')); ?></span>
													<span class="<?php if(Request::is('report/purchase-request-and-order-delivery')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
									</ul>
								</li>
							<?php endif; ?>
							<?php if(hasRole('report_purchase_order')): ?>
								<li class="nav-item <?php if(Request::is('report/purchase/order') || Request::is('report/purchase/order/*')){echo "active open";} ?>">
									<a class="nav-link nav-toggle">
										<i class="fa fa-file-pdf-o"></i>
										<span class="title"><?php echo e(trans('lang.order')); ?></span>
										<span class="arrow <?php if(Request::is('report/purchase/order') || Request::is('report/purchase/order/*')){echo "open";} ?>"></span>
									</a>
									<ul class="sub-menu">
										<?php if(hasRole('report_purchase_order_1')): ?>
											<li class="nav-item <?php if(Request::is('report/purchase/order')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/purchase/order')); ?>" class="nav-link ">
													<i class="fa fa-file-pdf-o"></i>
													<span class="title"><?php echo e(trans('rep.order')); ?></span>
													<span class="<?php if(Request::is('report/purchase/order')){echo "selected";} ?>"></span>
												</a>
											</li> 
										<?php endif; ?>
										<?php if(hasRole('report_purchase_order_2')): ?>
											<li class="nav-item <?php if(Request::is('report/purchase/order/order_1')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/purchase/order/order_1')); ?>" class="nav-link ">
													<i class="fa fa-home"></i>
													<span class="title"><?php echo e(trans('rep.order_1')); ?></span>
													<span class="<?php if(Request::is('report/purchase/order/order_1')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
										<?php if(hasRole('report_purchase_order_3')): ?>
											<li class="nav-item <?php if(Request::is('report/purchase/order/order_2')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/purchase/order/order_2')); ?>" class="nav-link ">
													<i class="fa fa-home"></i>
													<span class="title"><?php echo e(trans('rep.order_2')); ?></span>
													<span class="<?php if(Request::is('report/purchase/order/order_2')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
									</ul>
								</li>
							<?php endif; ?>
							<?php if(hasRole('report_delivery')): ?>
								<li class="nav-item <?php if(Request::is('report/delivery') || Request::is('report/return') || Request::is('report/delivery_details')){echo "active open";} ?>">
									<a class="nav-link nav-toggle">
										<i class="fa fa-truck"></i>
										<span class="title"><?php echo e(trans('lang.delivery')); ?></span>
										<span class="arrow <?php if(Request::is('report/delivery_details') || Request::is('report/delivery') || Request::is('report/return') || Request::is('report/delivery_details')){echo "open";} ?>"></span>
									</a>
									<ul class="sub-menu">
										<?php if(hasRole('report_delivery_item')): ?>
											<li class="nav-item <?php if(Request::is('report/delivery')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/delivery')); ?>" class="nav-link ">
													<i class="fa fa-area-chart"></i>
													<span class="title"><?php echo e(trans('rep.delivery')); ?></span>
													<span class="<?php if(Request::is('report/delivery')){echo "selected";} ?>"></span>
												</a>
											</li> 
										<?php endif; ?>
										<?php if(hasRole('report_delivery_item')): ?>
											<li class="nav-item <?php if(Request::is('report/delivery_details')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/delivery_details')); ?>" class="nav-link ">
													<i class="fa fa-area-chart"></i>
													<span class="title"><?php echo e(trans('lang.delivery_details')); ?></span>
													<span class="<?php if(Request::is('report/delivery_details')){echo "selected";} ?>"></span>
												</a>
											</li> 
										<?php endif; ?>
										<?php if(hasRole('report_return_delivery_item')): ?>
											<li class="nav-item <?php if(Request::is('report/return')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/return')); ?>" class="nav-link ">
													<i class="fa fa-exchange"></i>
													<span class="title"><?php echo e(trans('rep.return')); ?></span>
													<span class="<?php if(Request::is('report/return')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
										<?php if(hasRole('report_delivery_item')): ?>
											<li class="nav-item <?php if(Request::is('report/delivery-with-return')){echo "active open";} ?>">
												<a href="<?php echo e(url('report/delivery-with-return')); ?>" class="nav-link ">
													<i class="fa fa-truck"></i>
													<span class="title"><?php echo e(trans('rep.delivery_with_return')); ?></span>
													<span class="<?php if(Request::is('report/delivery-with-return')){echo "selected";} ?>"></span>
												</a>
											</li>
										<?php endif; ?>
									</ul>
								</li>
							<?php endif; ?>
							<li class="nav-item <?php if(Request::is('report/purchase_items')){echo "active open";} ?>">
								<a href="<?php echo e(url('report/purchase_items')); ?>" class="nav-link ">
									<i class="fa fa-area-chart"></i>
									<span class="title"><?php echo e(trans('lang.purchase_items')); ?></span>
									<span class="<?php if(Request::is('report/purchase_items')){echo "selected";} ?>"></span>
								</a>
							</li>
						</ul>
					</li>
				<?php endif; ?>
				<?php if(hasRole('report_stock')): ?>
				<li class="nav-item start <?php if(Request::is('report/stock_details') 
					|| Request::is('report/stock_balance') 
					|| Request::is('report/all_stock_transaction')
					|| Request::is('report/inventory/inventoryValuationDetail')
					|| Request::is('report/inventory/inventoryValuationDetailSubDataTable')
					|| Request::is('report/inventory/inventoryValuationSummary')
				){echo "active open";} ?>">
						<a class="nav-link nav-toggle">
							<i class="fa fa-university"></i>
							<span class="title"><?php echo e(trans('lang.stock')); ?></span>
							<span class="arrow <?php if(Request::is('report/stock_details') 
							|| Request::is('report/stock_balance') 
							|| Request::is('report/all_stock_transaction')
							|| Request::is('report/inventory/inventoryValuationDetail')
							|| Request::is('report/inventory/inventoryValuationDetailSubDataTable')
							|| Request::is('report/inventory/inventoryValuationSummary')
						){echo "open";} ?>"></span>
						</a>
						<ul class="sub-menu">
							<?php if(hasRole('report_stock_balance')): ?>
								<li class="nav-item <?php if(Request::is('report/stock_balance')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/stock_balance')); ?>" class="nav-link ">
										<i class="fa fa-balance-scale"></i>
										<span class="title"><?php echo e(trans('rep.stock_balance')); ?></span>
										<span class="<?php if(Request::is('report/stock_balance')){echo "selected";} ?>"></span>
									</a>
								</li> 
							<?php endif; ?>
							<?php if(hasRole('report_stock_balance')): ?>
								<li class="nav-item <?php if(Request::is('report/stock_details')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/stock_details')); ?>" class="nav-link ">
										<i class="fa fa-area-chart"></i>
										<span class="title"><?php echo e(trans('lang.stock_details')); ?></span>
										<span class="<?php if(Request::is('report/stock_details')){echo "selected";} ?>"></span>
									</a>
								</li> 
							<?php endif; ?>
							<?php if(hasRole('report_all_stock')): ?>
								<li class="nav-item <?php if(Request::is('report/all_stock_transaction')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/all_stock_transaction')); ?>" class="nav-link ">
										<i class="fa fa-bar-chart"></i>
										<span class="title"><?php echo e(trans('rep.all_stock_transaction')); ?></span>
										<span class="<?php if(Request::is('report/all_stock_transaction')){echo "selected";} ?>"></span>
									</a>
								</li>
							<?php endif; ?>
							<!-- Inventory Valuation Detail -->
							<?php if(true): ?>
								<li class="nav-item <?php if(Request::is('report/inventory/inventoryValuationDetail')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/inventory/inventoryValuationDetail')); ?>" class="nav-link ">
										<i class="fa fa-bar-chart"></i>
										<span class="title"><?php echo e(trans('lang.inventory_valuation_detail')); ?></span>
										<span class="<?php if(Request::is('report/inventory/inventoryValuationDetail')){echo "selected";} ?>"></span>
									</a>
								</li>
							<?php endif; ?>
							<!-- Inventory Valuation Summary -->
							<?php if(true): ?>
								<li class="nav-item <?php if(Request::is('report/inventory/inventoryValuationSummary')){echo "active open";} ?>">
									<a href="<?php echo e(url('report/inventory/inventoryValuationSummary')); ?>" class="nav-link ">
										<i class="fa fa-bar-chart"></i>
										<span class="title"><?php echo e(trans('lang.inventory_valuation_summary')); ?></span>
										<span class="<?php if(Request::is('report/inventory/inventoryValuationSummary')){echo "selected";} ?>"></span>
									</a>
								</li>
							<?php endif; ?>
						</ul>
					</li>
				<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>	
	
	<?php if(hasRole('user_control')): ?>
		<li class="nav-item <?php if(Request::is('user') || Request::is('depart') || Request::is('group') || Request::is('permis') || Request::is('role')){echo "active open";} ?>">
			<a  class="nav-link nav-toggle">
				<i class="icon-user"></i>
				<span class="title"><?php echo e(trans('lang.user_control')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('user') || Request::is('depart') || Request::is('group') || Request::is('permis') || Request::is('role')){echo "open";}?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('department')): ?>
				<li class="nav-item <?php if(Request::is('depart')){echo "active open";} ?>">
					<a href="<?php echo e(url('depart')); ?>" class="nav-link ">
						<i class="fa fa-sitemap"></i>
						<span class="title"><?php echo e(trans('lang.department')); ?></span>
						<span class="<?php if(Request::is('depart')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('user')): ?>
				<li class="nav-item <?php if(Request::is('user')){echo "active open";} ?>">
					<a href="<?php echo e(url('user')); ?>" class="nav-link ">
						<i class="icon-user"></i>
						<span class="title"><?php echo e(trans('lang.user_info')); ?></span>
						<span class="<?php if(Request::is('user')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('user_group')): ?>
				<li class="nav-item  <?php if(Request::is('group')){echo "active open";} ?>">
					<a href="<?php echo e(url('group')); ?>" class="nav-link ">
						<i class="icon-users"></i>
						<span class="title"><?php echo e(trans('lang.user_group')); ?></span>
						<span class="<?php if(Request::is('group')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('role')): ?>
				<li class="nav-item <?php if(Request::is('role')){echo "active open";} ?> ">
					<a href="<?php echo e(url('role')); ?>" class="nav-link ">
						<i class="fa fa-exclamation-triangle"></i>
						<span class="title"><?php echo e(trans('lang.role')); ?></span>
						<span class="<?php if(Request::is('role')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>	
	
	<?php if(hasRole('system')): ?>
		<li class="nav-item <?php if(Request::is('setting') || Request::is('trash') || Request::is('trash/*') || Request::is('activity') || Request::is('backup')){echo "active open";} ?>">
			<a  class="nav-link nav-toggle">
				<i class="icon-settings"></i>
				<span class="title"><?php echo e(trans('lang.system')); ?></span>
				<span class="selected"></span>
				<span class="arrow <?php if(Request::is('setting') || Request::is('period') || Request::is('trash') || Request::is('activity') || Request::is('backup')){echo "open";} ?>"></span>
			</a>
			<ul class="sub-menu">
			<?php if(hasRole('setting')): ?>
				<li class="nav-item <?php if(Request::is('setting')){echo "active open";} ?>">
					<a href="<?php echo e(url('setting')); ?>" class="nav-link ">
						<i class="fa fa-cogs"></i>
						<span class="title"><?php echo e(trans('lang.setting')); ?></span>
						<span class="<?php if(Request::is('setting')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('setting')): ?>
				<li class="nav-item <?php if(Request::is('format')){echo "active open";} ?>">
					<a href="<?php echo e(url('format/index')); ?>" class="nav-link ">
						<i class="fa fa-file-o"></i>
						<span class="title"><?php echo e(trans('lang.format_info')); ?></span>
						<span class="<?php if(Request::is('format')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('user_log')): ?>
				<li class="nav-item <?php if(Request::is('activity')){echo "active open";} ?>">
					<a href="<?php echo e(url('activity')); ?>" class="nav-link ">
						<i class="fa fa-expeditedssl"></i>
						<span class="title"><?php echo e(trans('lang.user_activity')); ?></span>
						<span class="<?php if(Request::is('activity')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('backup')): ?>
				<li class="nav-item <?php if(Request::is('backup')){echo "active open";} ?>">
					<a href="<?php echo e(url('backup')); ?>" class="nav-link ">
						<i class="fa fa-database"></i>
						<span class="title"><?php echo e(trans('lang.backup')); ?></span>
						<span class="<?php if(Request::is('backup')){echo "selected";} ?>"></span>
					</a>
				</li>
			<?php endif; ?>
			<?php if(hasRole('trash')): ?>
				<li class="nav-item <?php if(Request::is('trash') || Request::is('trash/*')){echo "active open";} ?>">
					<a  class="nav-link nav-toggle">
						<i class="fa fa-trash-o"></i>
						<span class="title"><?php echo e(trans('lang.trash')); ?></span>
						<span class="arrow <?php if(Request::is('trash') || Request::is('trash/*')){echo "open";} ?>"></span>
					</a>
					<ul class="sub-menu">
					<?php if(hasRole('trash_stock_entry')): ?>
						<li class="nav-item <?php if(Request::is('trash/entry')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/entry')); ?>" class="nav-link ">
								<i class="fa fa-sign-in"></i>
								<span class="title"><?php echo e(trans('lang.stock_entry')); ?></span>
								<span class="<?php if(Request::is('trash/entry')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_stock_import')): ?>
						<li class="nav-item <?php if(Request::is('trash/import')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/import')); ?>" class="nav-link ">
								<i class="fa fa-upload"></i>
								<span class="title"><?php echo e(trans('lang.stock_import')); ?></span>
								<span class="<?php if(Request::is('trash/import')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_stock_adjust')): ?>
						<li class="nav-item <?php if(Request::is('trash/adjust')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/adjust')); ?>" class="nav-link ">
								<i class="fa fa-adjust"></i>
								<span class="title"><?php echo e(trans('lang.adjustment')); ?></span>
								<span class="<?php if(Request::is('trash/adjust')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_stock_move')): ?>
						<li class="nav-item <?php if(Request::is('trash/move')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/move')); ?>" class="nav-link ">
								<i class="fa fa-arrows"></i>
								<span class="title"><?php echo e(trans('lang.movement')); ?></span>
								<span class="<?php if(Request::is('trash/move')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_stock_delivery')): ?>
						<li class="nav-item <?php if(Request::is('trash/delivery')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/delivery')); ?>" class="nav-link ">
								<i class="fa fa-truck"></i>
								<span class="title"><?php echo e(trans('lang.delivery')); ?></span>
								<span class="<?php if(Request::is('trash/delivery')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_stock_return_delivery')): ?>
						<li class="nav-item <?php if(Request::is('trash/redelivery')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/redelivery')); ?>" class="nav-link ">
								<i class="fa fa-exchange"></i>
								<span class="title"><?php echo e(trans('lang.return_delivery')); ?></span>
								<span class="<?php if(Request::is('trash/redelivery')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_stock_usage')): ?>
						<li class="nav-item <?php if(Request::is('trash/usage')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/usage')); ?>" class="nav-link ">
								<i class="fa fa-legal"></i>
								<span class="title"><?php echo e(trans('lang.usage')); ?></span>
								<span class="<?php if(Request::is('trash/usage')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_stock_return_usage')): ?>
						<li class="nav-item <?php if(Request::is('trash/reusage')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/reusage')); ?>" class="nav-link ">
								<i class="fa fa-exchange"></i>
								<span class="title"><?php echo e(trans('lang.return_usage')); ?></span>
								<span class="<?php if(Request::is('trash/reusage')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_request')): ?>
						<li class="nav-item <?php if(Request::is('trash/request')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/request')); ?>" class="nav-link ">
								<i class="fa fa-registered"></i>
								<span class="title"><?php echo e(trans('lang.request')); ?></span>
								<span class="<?php if(Request::is('trash/request')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					<?php if(hasRole('trash_order')): ?>
						<li class="nav-item <?php if(Request::is('trash/order')){echo "active open";} ?>">
							<a href="<?php echo e(url('trash/order')); ?>" class="nav-link ">
								<i class="icon-basket"></i>
								<span class="title"><?php echo e(trans('lang.order')); ?></span>
								<span class="<?php if(Request::is('trash/order')){echo "selected";} ?>"></span>
							</a>
						</li>
					<?php endif; ?>
					</ul>
				</li>
			<?php endif; ?>
			</ul>
		</li>
	<?php endif; ?>	
	</ul>
	<!-- END SIDEBAR MENU -->
</div>
<!-- END SIDEBAR -->